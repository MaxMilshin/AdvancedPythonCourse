from latexgen.latex import generate_latex_table 
from latexgen.latex import generate_image_latex
from latexgen.latex import complete_latex_file